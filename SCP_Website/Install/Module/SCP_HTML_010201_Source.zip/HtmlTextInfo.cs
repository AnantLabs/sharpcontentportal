//
// Sharp Content Portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Configuration;
using System.Data;

namespace SharpContent.Modules.HTML
{

	public class HtmlTextInfo
	{
		// local property declarations
		private int _ModuleId;
		private string _DeskTopHTML;
		private string _DesktopSummary;
		private int _CreatedByUser;
		private DateTime _CreatedDate;

		// initialization
		public HtmlTextInfo()
		{
		}

		// public properties
		public int ModuleId {
			get { return _ModuleId; }
			set { _ModuleId = value; }
		}

		public string DeskTopHTML {
			get { return _DeskTopHTML; }
			set { _DeskTopHTML = value; }
		}

		public string DesktopSummary {
			get { return _DesktopSummary; }
			set { _DesktopSummary = value; }
		}

		public int CreatedByUser {
			get { return _CreatedByUser; }
			set { _CreatedByUser = value; }
		}

		public DateTime CreatedDate {
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

	}

}

