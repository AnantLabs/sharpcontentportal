//
// Sharp Content Portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using SharpContent;
using SharpContent.Common;
using SharpContent.Modules.HTML;
using SharpContent.Services.Exceptions;
using SharpContent.Services.Localization;
using SharpContent.UI.Utilities;

namespace SharpContent.Modules.Html
{

	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The EditHtml PortalModuleBase is used to manage Html
	/// </summary>
	/// <remarks>
	/// </remarks>
	/// <history>
	/// </history>
	/// -----------------------------------------------------------------------------
    public partial class EditHtml : Entities.Modules.PortalModuleBase
    {

        #region "Private Members"

        protected bool _isNew = true;

        #endregion

        #region "Event Handlers"

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <history>
        /// </history>
        /// -----------------------------------------------------------------------------
        protected void Page_Load(object sender, System.EventArgs e)
        {
            try
            {

                // get HtmlText object
                HtmlTextController objHTML = new HtmlTextController();
                HtmlTextInfo objText = objHTML.GetHtmlText(ModuleId);

                // get the IsNew state from the ViewState
                _isNew = Convert.ToBoolean(ViewState["IsNew"]);

                if (Page.IsPostBack == false)
                {
                    if ((objText != null))
                    {
                        // initialize control values
                        teContent.Text = objText.DeskTopHTML;
                        txtDesktopSummary.Text = Server.HtmlDecode((string)objText.DesktopSummary);
                        _isNew = false;
                    }
                    else
                    {
                        // get default content from resource file
                        teContent.Text = Localization.GetString("AddContent", LocalResourceFile);
                        txtDesktopSummary.Text = "";
                        _isNew = true;
                    }
                }

                // save the IsNew state to the ViewState
                ViewState["IsNew"] = _isNew;
            }

            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// cmdCancel_Click runs when the cancel button is clicked
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <history>
        /// </history>
        /// -----------------------------------------------------------------------------
        protected void cmdCancel_Click(object sender, System.EventArgs e)
        {
            try
            {
                Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// cmdPreview_Click runs when the preview button is clicked
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <history>
        /// </history>
        /// -----------------------------------------------------------------------------
        protected void cmdPreview_Click(object sender, System.EventArgs e)
        {
            try
            {
                string strDesktopHTML;

                strDesktopHTML = teContent.Text;

                lblPreview.Text = SharpContent.Common.Globals.ManageUploadDirectory(Server.HtmlDecode(strDesktopHTML), PortalSettings.HomeDirectory);
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// cmdUpdate_Click runs when the update button is clicked
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <history>
        /// </history>
        /// -----------------------------------------------------------------------------
        protected void cmdUpdate_Click(object sender, System.EventArgs e)
        {
            try
            {
                // create HTMLText object
                HtmlTextController objHTML = new HtmlTextController();
                HtmlTextInfo objText = new HtmlTextInfo();

                // set content values
                objText.ModuleId = ModuleId;
                objText.DeskTopHTML = teContent.Text;
                objText.DesktopSummary = txtDesktopSummary.Text;
                objText.CreatedByUser = this.UserId;

                // save the content
                if (_isNew)
                {
                    objHTML.AddHtmlText(objText);
                }
                else
                {
                    objHTML.UpdateHtmlText(objText);
                }

                // refresh cache
                SynchronizeModule();

                // redirect back to portal
                Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        #endregion
    }

}
