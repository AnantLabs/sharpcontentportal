//
// Sharp Content Portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Data;
using System.Data.SqlClient;
using SharpContent.ApplicationBlocks.Data;
using SharpContent.Common.Utilities;

namespace SharpContent.Modules.HTML
{

	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The SqlDataProvider Class is an SQL Server implementation of the DataProvider Abstract
	/// class that provides the DataLayer for the HTML Module.
	/// </summary>
	/// <remarks>
	/// </remarks>
	/// <history>
	/// </history>
	/// -----------------------------------------------------------------------------
	public class SqlDataProvider : DataProvider
	{


		#region "Private Members"

		private const string ProviderType = "data";

		private Framework.Providers.ProviderConfiguration _providerConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(ProviderType);
		private string _connectionString;
		private string _providerPath;
		private string _objectQualifier;
		private string _databaseOwner;

		#endregion

		#region "Constructors"

		public SqlDataProvider()
		{

			// Read the configuration specific information for this provider
			Framework.Providers.Provider objProvider = (Framework.Providers.Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];

			// Read the attributes for this provider
			_connectionString = Config.GetConnectionString();

			_providerPath = objProvider.Attributes["providerPath"];

			_objectQualifier = objProvider.Attributes["objectQualifier"];
			if (_objectQualifier != "" & _objectQualifier.EndsWith("_") == false)
			{
				_objectQualifier += "_";
			}

			_databaseOwner = objProvider.Attributes["databaseOwner"];
			if (_databaseOwner != "" & _databaseOwner.EndsWith(".") == false)
			{
				_databaseOwner += ".";
			}

		}

		#endregion

		#region "Properties"

		public string ConnectionString {
			get { return _connectionString; }
		}

		public string ProviderPath {
			get { return _providerPath; }
		}

		public string ObjectQualifier {
			get { return _objectQualifier; }
		}

		public string DatabaseOwner {
			get { return _databaseOwner; }
		}

		#endregion

		#region "Public Methods"

		private object GetNull(object Field)
		{
			return Common.Utilities.Null.GetNull(Field, DBNull.Value);
		}

		public override void AddHtmlText(int moduleId, string desktopHtml, string desktopSummary, int userID)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner + ObjectQualifier + "AddHtmlText", moduleId, desktopHtml, desktopSummary, userID);
		}

		public override IDataReader GetHtmlText(int moduleId)
		{
			return (IDataReader)SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner + ObjectQualifier + "GetHtmlText", moduleId);
		}

		public override void UpdateHtmlText(int moduleId, string desktopHtml, string desktopSummary, int userID)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner + ObjectQualifier + "UpdateHtmlText", moduleId, desktopHtml, desktopSummary, userID);
		}

		#endregion

	}

}
