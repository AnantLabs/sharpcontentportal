//
// Sharp Content portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2006
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System;
using System.Collections;
using System.Text;
using SharpContent.Entities.Users;


namespace SharpContent.Modules.IFrame.Domain
{

	/// <summary>
	/// Represents a collection of <see cref="IFrameParameter"/> objects.
	/// </summary>
	/// <history>
	///     [flanakin]   04/15/2006     Genesis
	/// </history>
	public sealed class IFrameParameterCollection : CollectionBase
	{

		#region "| Fields |"

		private IFrameParameter.UniqueKey _key;
		private int _moduleID;
		private string _ParamName;
		private IFrameParameterType _type;
		private string _typeArgument;

		#endregion


		#region "| Initialization |"

		/// <summary>
		/// Instantiates a new instance of the <c>IFrameParameterCollection</c> module.
		/// </summary>
		public IFrameParameterCollection()
		{
		}

		#endregion


		#region "| Properties |"

		
		#endregion


		#region "| Methods [Public] |"

          public IFrameParameter Item(int index)
          {
              return (IFrameParameter)this.List[index];
          }


          public IFrameParameter Item(string paramName)
          {
              return (IFrameParameter)(this.List[IndexOf(paramName)]);
          }

		public int Add(IFrameParameter Param)
		{
			return this.List.Add(Param);
		}


		public bool Contains(IFrameParameter param)
		{
			return this.List.Contains(param);
		}


		public bool Contains(string paramName)
		{
			return (IndexOf(paramName) >= 0);
		}


		public int IndexOf(IFrameParameter Param)
		{
			return this.List.IndexOf(Param);
		}


		public int IndexOf(string ParamName)
		{
			for (int i = 0; i <= Count - 1; i++) {
				if (this.Item(i).Name == ParamName)
				{
					return i;
				}
			}
			return -1;
		}


		public void Remove(IFrameParameter Param)
		{
			InnerList.Remove(Param);
		}


		public void Remove(string ParamName)
		{
			this.RemoveAt(IndexOf(ParamName));
		}


		public override string ToString()
		{
			StringBuilder sbValue = new StringBuilder();
			bool bParameterAdded = false;
			for (int i = 0; i <= this.Count - 1; i++) {
				string param = this.Item(i).ToString();
				if (param.Length > 0)
				{
					if (bParameterAdded) sbValue.Append("&"); 
					sbValue.Append(param);
					bParameterAdded = true;
				}
			}
			return sbValue.ToString();
		}

		#endregion


		#region "| Methods [Protected] |"

		protected override void OnValidate(object value)
		{
			if (!(value is IFrameParameter))
			{
				throw new ArgumentException("Must add a IFrameParameter");
			}
		}

		#endregion

	}
}

