//
// Sharp Content Portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Configuration;
using System.Data;
using SharpContent.Services.Search;
using SharpContent;
using SharpContent.Common;
using System.Xml;
using System.Web;
using SharpContent.Common.Utilities;

namespace SharpContent.Modules.HTML
{

	/// -----------------------------------------------------------------------------
	/// Namespace:  SharpContent.Modules.Html
	/// Project:    SharpContentPortal
	/// Class:      HtmlTextController
	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The HtmlTextController is the Controller class for the HtmlText Module
	/// </summary>
	/// <remarks>
	/// </remarks>
	/// <history>
	///		[cnurse]	11/15/2004	documented
	///     [cnurse]    11/16/2004  Add/UpdateHtmlText separated into two methods,
	///                             GetSearchItems modified to use decoded content
	/// </history>
	/// -----------------------------------------------------------------------------
	public class HtmlTextController : Entities.Modules.ISearchable, Entities.Modules.IPortable
	{

		private const int MAX_DESCRIPTION_LENGTH = 100;

		#region "Public Methods"

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// AddHtmlText adds a HtmlTextInfo object to the Database
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="objText">The HtmlTextInfo object</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public void AddHtmlText(HtmlTextInfo objText)
		{

			DataProvider.Instance().AddHtmlText(objText.ModuleId, objText.DeskTopHTML, objText.DesktopSummary, objText.CreatedByUser);

		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// GetHtmlText gets the HtmlTextInfo object from the Database
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="moduleId">The Id of the module</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public HtmlTextInfo GetHtmlText(int moduleId)
		{

			return (HtmlTextInfo)CBO.FillObject(DataProvider.Instance().GetHtmlText(moduleId), typeof(HtmlTextInfo));

		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// UpdateHtmlText saves the HtmlTextInfo object to the Database
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="objText">The HtmlTextInfo object</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public void UpdateHtmlText(HtmlTextInfo objText)
		{

			DataProvider.Instance().UpdateHtmlText(objText.ModuleId, objText.DeskTopHTML, objText.DesktopSummary, objText.CreatedByUser);

		}

		#endregion

		#region "Optional Interfaces"

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// GetSearchItems implements the ISearchable Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		///     [skamphuis] 03/11/2006  FIX: HTM-2632. Enabled Search Summary.
		/// </history>
		/// -----------------------------------------------------------------------------
		public SearchItemInfoCollection GetSearchItems(Entities.Modules.ModuleInfo ModInfo)
		{

			SearchItemInfoCollection SearchItemCollection = new SearchItemInfoCollection();

			HtmlTextInfo HtmlText = GetHtmlText(ModInfo.ModuleID);

			if ((HtmlText != null))
			{
				//DesktopHTML is encoded in the Database so Decode before Indexing
				string strDesktopHtml = HttpUtility.HtmlDecode(HtmlText.DeskTopHTML);

				//Get the description string
				string strDescription = HtmlUtils.Shorten(HtmlUtils.Clean(strDesktopHtml, false), MAX_DESCRIPTION_LENGTH, "...");

				SearchItemInfo SearchItem = new SearchItemInfo(ModInfo.ModuleTitle, strDescription, HtmlText.CreatedByUser, HtmlText.CreatedDate, ModInfo.ModuleID, "", HtmlText.DesktopSummary + " " + strDesktopHtml, "", Null.NullInteger);
				SearchItemCollection.Add(SearchItem);
			}
			return SearchItemCollection;

		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// ExportModule implements the IPortable ExportModule Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModuleID">The Id of the module to be exported</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public string ExportModule(int ModuleID)
		{

			string strXML = "";

			HtmlTextInfo objHtmlText = GetHtmlText(ModuleID);
			if ((objHtmlText != null))
			{
				strXML += "<htmltext>";
				strXML += "<desktophtml>" + Common.Utilities.XmlUtils.XMLEncode(objHtmlText.DeskTopHTML) + "</desktophtml>";
				strXML += "<desktopsummary>" + Common.Utilities.XmlUtils.XMLEncode(objHtmlText.DesktopSummary) + "</desktopsummary>";
				strXML += "</htmltext>";
			}

			return strXML;

		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// ImportModule implements the IPortable ImportModule Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModuleID">The Id of the module to be imported</param>
		/// <history>
		///		[cnurse]	11/15/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public void ImportModule(int ModuleID, string Content, string Version, int UserId)
		{

			XmlNode xmlHtmlText = Globals.GetContent(Content, "htmltext");

			HtmlTextInfo objText = new HtmlTextInfo();

			objText.ModuleId = ModuleID;
			objText.CreatedByUser = UserId;

			//Get the original item
			HtmlTextInfo objTextOld = this.GetHtmlText(ModuleID);

			//See if there was an item already
			if (objTextOld == null)
			{
				//Need to insert the imported item
				objText.DeskTopHTML = xmlHtmlText.SelectSingleNode("desktophtml").InnerText;
				objText.DesktopSummary = xmlHtmlText.SelectSingleNode("desktopsummary").InnerText;
				AddHtmlText(objText);
			}
			else
			{
				//Need to appende the imported item to the existing item
				objText.DeskTopHTML = objTextOld.DeskTopHTML + xmlHtmlText.SelectSingleNode("desktophtml").InnerText;
				objText.DesktopSummary = objTextOld.DesktopSummary + xmlHtmlText.SelectSingleNode("desktopsummary").InnerText;
				UpdateHtmlText(objText);
			}

		}

		#endregion

	}
}

