//
// Sharp Content Portal - http://www.sharpcontentportal.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Data;
using System.Data.SqlClient;
using SharpContent.ApplicationBlocks.Data;
using SharpContent.Common.Utilities;

namespace SharpContent.Modules.Links
{

	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The SqlDataProvider Class is an SQL Server implementation of the DataProvider Abstract
	/// class that provides the DataLayer for the Links Module.
	/// </summary>
	/// <returns></returns>
	/// <remarks>
	/// </remarks>
	/// <history>
	/// 	[cnurse]	9/23/2004	Moved Links to a separate Project
	/// </history>
	/// -----------------------------------------------------------------------------
	public class SqlDataProvider : DataProvider
	{


		#region "Private Members"

		private const string ProviderType = "data";

		private Framework.Providers.ProviderConfiguration _providerConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(ProviderType);
		private string _connectionString;
		private string _providerPath;
		private string _objectQualifier;
		private string _databaseOwner;

		#endregion

		#region "Constructors"

		public SqlDataProvider()
		{

			// Read the configuration specific information for this provider
			Framework.Providers.Provider objProvider = (Framework.Providers.Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];

			// Read the attributes for this provider
               if (objProvider.Attributes["connectionStringName"] != "" && System.Configuration.ConfigurationManager.AppSettings[objProvider.Attributes["connectionStringName"]] != "")
			{
				_connectionString = Config.GetConnectionString();
			}
			else
			{
				_connectionString = objProvider.Attributes["connectionString"];
			}

			_providerPath = objProvider.Attributes["providerPath"];

			_objectQualifier = objProvider.Attributes["objectQualifier"];
			if (_objectQualifier != "" & _objectQualifier.EndsWith("_") == false)
			{
				_objectQualifier += "_";
			}

			_databaseOwner = objProvider.Attributes["databaseOwner"];
			if (_databaseOwner != "" & _databaseOwner.EndsWith(".") == false)
			{
				_databaseOwner += ".";
			}

		}

		#endregion

		#region "Properties"

		public string ConnectionString {
			get { return _connectionString; }
		}

		public string ProviderPath {
			get { return _providerPath; }
		}

		public string ObjectQualifier {
			get { return _objectQualifier; }
		}

		public string DatabaseOwner {
			get { return _databaseOwner; }
		}

		#endregion

		#region "Public Methods"

		private object GetNull(object Field)
		{
			return Common.Utilities.Null.GetNull(Field, DBNull.Value);
		}

		public override int AddLink(int ModuleId, int UserId, string Title, string Url, int ViewOrder, string Description)
		{
			return (int)SqlHelper.ExecuteScalar(ConnectionString, DatabaseOwner + ObjectQualifier + "AddLink", ModuleId, UserId, Title, Url, GetNull(ViewOrder), Description);
		}

		public override void DeleteLink(int ItemId, int ModuleId)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner + ObjectQualifier + "DeleteLink", ItemId, ModuleId);
		}

		public override IDataReader GetLink(int ItemId, int ModuleId)
		{
			return (IDataReader)SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner + ObjectQualifier + "GetLink", ItemId, ModuleId);
		}

		public override IDataReader GetLinks(int ModuleId)
		{
			return (IDataReader)SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner + ObjectQualifier + "GetLinks", ModuleId);
		}

		public override void UpdateLink(int ItemId, int UserId, string Title, string Url, string ViewOrder, string Description)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, DatabaseOwner + ObjectQualifier + "UpdateLink", ItemId, UserId, Title, Url, GetNull(ViewOrder), Description);
		}

		#endregion

	}
}

