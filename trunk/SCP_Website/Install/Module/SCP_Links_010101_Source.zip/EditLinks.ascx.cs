using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SharpContent.Services.Localization;
using SharpContent.Services.Exceptions;
using SharpContent.Common.Utilities;


namespace SharpContent.Modules.Links
{
    public partial class EditLinks : Entities.Modules.PortalModuleBase
    {
        private int itemId = -1;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Entities.Modules.ModuleController objModules = new Entities.Modules.ModuleController();

                // Determine ItemId of Link to Update
                if ((Request.QueryString["ItemId"] != null))
                {
                    itemId = Int32.Parse(Request.QueryString["ItemId"]);
                }

                // If the page is being requested the first time, determine if an
                // link itemId value is specified, and if so populate page
                // contents with the link details
                if (Page.IsPostBack == false)
                {

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" + Localization.GetString("DeleteItem") + "');");

                    if (itemId != -1)
                    {

                        // Obtain a single row of link information
                        LinkController objLinks = new LinkController();
                        LinkInfo objLink = objLinks.GetLink(itemId, ModuleId);

                        if ((objLink != null))
                        {

                            txtTitle.Text = objLink.Title.ToString();

                            ctlURL.Url = objLink.Url;
                            ctlURL.ShowDatabase = true;
                            ctlURL.ShowSecure = true;

                            txtDescription.Text = objLink.Description.ToString();

                            if ((Common.Utilities.Null.IsNull(objLink.ViewOrder) == false))
                            {
                                txtViewOrder.Text = Convert.ToString(objLink.ViewOrder);
                            }

                            ctlAudit.CreatedByUser = objLink.CreatedByUser.ToString();
                            ctlAudit.CreatedDate = objLink.CreatedDate.ToString();

                            ctlTracking.URL = objLink.Url;
                            ctlTracking.ModuleID = ModuleId;
                        }

                        else
                        {
                            // security violation attempt to access item not related to this Module
                            Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
                        }
                    }
                    else
                    {
                        cmdDelete.Visible = false;
                        ctlAudit.Visible = false;
                        ctlTracking.Visible = false;
                    }

                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }
        protected void cmdUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                if (Page.IsValid == true & ctlURL.Url != "")
                {

                    LinkInfo objLink = new LinkInfo();

                    objLink = (LinkInfo)CBO.InitializeObject(objLink, typeof(LinkInfo));

                    //bind text values to object
                    objLink.ItemId = itemId;
                    objLink.ModuleId = ModuleId;
                    objLink.CreatedByUser = UserInfo.UserID;
                    objLink.Title = txtTitle.Text;
                    objLink.Url = ctlURL.Url;
                    if ((txtViewOrder.Text.Length > 0))
                    {
                        objLink.ViewOrder = Convert.ToInt32(txtViewOrder.Text);
                    }
                    objLink.Description = txtDescription.Text;

                    // Create an instance of the Link DB component
                    LinkController objLinks = new LinkController();

                    if (Common.Utilities.Null.IsNull(itemId))
                    {
                        objLinks.AddLink(objLink);
                    }
                    else
                    {
                        objLinks.UpdateLink(objLink);
                    }
                    SynchronizeModule();

                    // url tracking
                    UrlController objUrls = new UrlController();
                    objUrls.UpdateUrl(PortalId, ctlURL.Url, ctlURL.UrlType, ctlURL.Log, ctlURL.Track, ModuleId, ctlURL.NewWindow);

                    // Redirect back to the portal home page
                    Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
                }
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }
        protected void cmdCancel_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }
        protected void cmdDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (itemId != -1)
                {

                    LinkController links = new LinkController();
                    links.DeleteLink(itemId, ModuleId);
                    SynchronizeModule();

                }

                // Redirect back to the portal home page
                Response.Redirect(SharpContent.Common.Globals.NavigateURL(), true);
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }
}
}
