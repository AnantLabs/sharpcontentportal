//
// CSharpNuke® - http://www.CSharpNuke.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Data;
using Oracle.DataAccess.Client;
using Microsoft.ApplicationBlocks.Data;
using CSharpNuke.Common.Utilities;

namespace CSharpNuke.Modules.Links
{

	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The SqlDataProvider Class is an SQL Server implementation of the DataProvider Abstract
	/// class that provides the DataLayer for the Links Module.
	/// </summary>
	/// <returns></returns>
	/// <remarks>
	/// </remarks>
	/// <history>
	/// 	[cnurse]	9/23/2004	Moved Links to a separate Project
	/// </history>
	/// -----------------------------------------------------------------------------
	public class OracleDataProvider : DataProvider
	{
	    #region "Private Members"

	    private const string ProviderType = "data";

	    private Framework.Providers.ProviderConfiguration _providerConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(ProviderType);
	    private string _connectionString;
	    private string _providerPath;
	    private string _packageName;
	    private string _databaseOwner;

	    #endregion

	    #region "Constructors"

	    public OracleDataProvider()
	    {

		    // Read the configuration specific information for this provider
		    Framework.Providers.Provider objProvider = (Framework.Providers.Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];

		    // Read the attributes for this provider
              if (objProvider.Attributes["connectionStringName"] != "" && System.Configuration.ConfigurationManager.AppSettings[objProvider.Attributes["connectionStringName"]] != "")
		    {
			    _connectionString = Config.GetConnectionString();
		    }
		    else
		    {
			    _connectionString = objProvider.Attributes["connectionString"];
		    }

		    _providerPath = objProvider.Attributes["providerPath"];

		    _packageName = "csn_links_pkg.csn_";

		    _databaseOwner = objProvider.Attributes["databaseOwner"];
		    if (_databaseOwner != "" & _databaseOwner.EndsWith(".") == false)
		    {
			    _databaseOwner += ".";
		    }

	    }

	    #endregion

	    #region "Properties"

	    public string ConnectionString {
		    get { return _connectionString; }
	    }

	    public string ProviderPath {
		    get { return _providerPath; }
	    }

	    public string PackageName {
		    get { return _packageName; }
	    }

	    public string DatabaseOwner {
		    get { return _databaseOwner; }
	    }

	    #endregion

	    #region "Public Methods"

	    private object GetNull(object Field)
	    {
		    return Common.Utilities.Null.GetNull(Field, DBNull.Value);
	    }
         
         public override int AddLink(int i_moduleid, int i_userid, string i_title, string i_url, int i_vieworder, string i_description)
         {
             OracleParameter[] parms = {
		    new OracleParameter("i_moduleid", OracleDbType.Int32), 
		    new OracleParameter("i_userid", OracleDbType.Int32), 
		    new OracleParameter("i_title", OracleDbType.NVarchar2), 
		    new OracleParameter("i_url", OracleDbType.NVarchar2), 
		    new OracleParameter("i_vieworder", OracleDbType.Int32), 
		    new OracleParameter("i_description", OracleDbType.NVarchar2), 
		    new OracleParameter("o_moduleid", OracleDbType.Int32)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_moduleid;
             parms[1].Direction = ParameterDirection.Input;
             parms[1].Value = i_userid;
             parms[2].Direction = ParameterDirection.Input;
             parms[2].Value = i_title;
             parms[3].Direction = ParameterDirection.Input;
             parms[3].Value = i_url;
             parms[4].Direction = ParameterDirection.Input;
             parms[4].Value = GetNull(i_vieworder);
             parms[5].Direction = ParameterDirection.Input;
             parms[5].Value = i_description;
             parms[6].Direction = ParameterDirection.Output;

             OracleHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "ADDLINK", parms);
             return Convert.ToInt32(parms[6].Value.ToString());
         }
         
         public override void DeleteLink(int i_itemid, int i_moduleid)
         {
             OracleParameter[] parms = {
		    new OracleParameter("i_itemid", OracleDbType.Int32), 
		    new OracleParameter("i_moduleid", OracleDbType.Int32)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_itemid;
             parms[1].Direction = ParameterDirection.Input;
             parms[1].Value = i_moduleid;

             OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "DELETELINK", parms);
         }

         public override IDataReader GetLink(int i_itemid, int i_moduleid)
         {
             OracleParameter[] parms = {
		    new OracleParameter("i_itemid", OracleDbType.Int32), 
		    new OracleParameter("i_moduleid", OracleDbType.Int32), 
		    new OracleParameter("o_rc1", OracleDbType.RefCursor)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_itemid;
             parms[1].Direction = ParameterDirection.Input;
             parms[1].Value = i_moduleid;
             parms[2].Direction = ParameterDirection.Output;

             return OracleHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "GETLINK", parms);
         }

         public override IDataReader GetLinks(int i_moduleid)
         {
             OracleParameter[] parms = {
		    new OracleParameter("i_moduleid", OracleDbType.Int32), 
		    new OracleParameter("o_rc1", OracleDbType.RefCursor)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_moduleid;
             parms[1].Direction = ParameterDirection.Output;

             return OracleHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "GETLINKS", parms);
         }
         
         public override void UpdateLink(int i_itemid, int i_userid, string i_title, string i_url, string i_vieworder, string i_description)
         {
             OracleParameter[] parms = {
		    new OracleParameter("i_itemid", OracleDbType.Int32), 
		    new OracleParameter("i_userid", OracleDbType.Int32), 
		    new OracleParameter("i_title", OracleDbType.NVarchar2), 
		    new OracleParameter("i_url", OracleDbType.NVarchar2), 
		    new OracleParameter("i_vieworder", OracleDbType.Int32), 
		    new OracleParameter("i_description", OracleDbType.NVarchar2)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_itemid;
             parms[1].Direction = ParameterDirection.Input;
             parms[1].Value = i_userid;
             parms[2].Direction = ParameterDirection.Input;
             parms[2].Value = i_title;
             parms[3].Direction = ParameterDirection.Input;
             parms[3].Value = i_url;
             parms[4].Direction = ParameterDirection.Input;
             parms[4].Value = GetNull(i_vieworder);
             parms[5].Direction = ParameterDirection.Input;
             parms[5].Value = i_description;

             OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "UPDATELINK", parms);
         }

	    #endregion

	}
}

