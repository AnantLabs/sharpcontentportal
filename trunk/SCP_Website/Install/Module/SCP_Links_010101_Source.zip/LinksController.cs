//
// CSharpNuke® - http://www.CSharpNuke.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Configuration;
using System.Data;
using System.Text;
using System.Xml;
using System.Collections;
using CSharpNuke.Common;
using CSharpNuke.Common.Utilities;
using CSharpNuke.Services.Search;
namespace CSharpNuke.Modules.Links
{


	/// -----------------------------------------------------------------------------
	/// Namespace:  CSharpNuke.Modules.Links
	/// Project:    CSharpNuke
	/// Class:      LinkController
	/// -----------------------------------------------------------------------------
	/// <summary>
	/// The LinkController Class represents the Links Business Layer
	/// Methods in this class call methods in the Data Layer
	/// </summary>
	/// <returns></returns>
	/// <remarks>
	/// </remarks>
	/// <history>
	/// 	[cnurse]	9/23/2004	Moved Links to a separate Project
	/// </history>
	/// -----------------------------------------------------------------------------
	public class LinkController : Entities.Modules.ISearchable, Entities.Modules.IPortable
	{

		#region "Public Methods"

		public void AddLink(LinkInfo objLink)
		{

			DataProvider.Instance().AddLink(objLink.ModuleId, objLink.CreatedByUser, objLink.Title, objLink.Url, objLink.ViewOrder, objLink.Description);

		}

		public void DeleteLink(int ItemID, int ModuleId)
		{

			DataProvider.Instance().DeleteLink(ItemID, ModuleId);

		}

		public LinkInfo GetLink(int ItemID, int ModuleId)
		{
			IDataReader dr = null;
			try {
				dr = DataProvider.Instance().GetLink(ItemID, ModuleId);
				return (LinkInfo)FillLink(dr);
			}
			finally {
				if ((dr != null))
				{
					dr.Close();
				}
			}
		}

		public ArrayList GetLinks(int ModuleId)
		{
			IDataReader dr = null;
			try {
				dr = DataProvider.Instance().GetLinks(ModuleId);
				return FillLinks(dr);
			}
			finally {
				if ((dr != null))
				{
					dr.Close();
				}
			}
		}

		public void UpdateLink(LinkInfo objLink)
		{

			DataProvider.Instance().UpdateLink(objLink.ItemId, objLink.CreatedByUser, objLink.Title, objLink.Url, objLink.ViewOrder.ToString(), objLink.Description);

		}

		#endregion

		#region "Custom Hydrator"
		private LinkInfo FillLink(IDataReader dr)
		{
			LinkInfo linkInfo = new LinkInfo();

			while (dr.Read()) {
				linkInfo.ItemId = Convert.ToInt32(Null.SetNull(dr["ItemId"], linkInfo.ItemId));
				linkInfo.ModuleId = Convert.ToInt32(Null.SetNull(dr["ModuleId"], linkInfo.ModuleId));
				linkInfo.Title = Convert.ToString(Null.SetNull(dr["Title"], linkInfo.Title));
				linkInfo.Url = Convert.ToString(Null.SetNull(dr["URL"], linkInfo.Url));
				linkInfo.ViewOrder = Convert.ToInt32(Null.SetNull(dr["ViewOrder"], linkInfo.ViewOrder));
				linkInfo.Description = Convert.ToString(Null.SetNull(dr["Description"], linkInfo.Description));
				linkInfo.CreatedByUser = Convert.ToInt32(Null.SetNull(dr["CreatedByUser"], linkInfo.CreatedByUser));
				linkInfo.CreatedDate = Convert.ToDateTime(Null.SetNull(dr["CreatedDate"], linkInfo.CreatedDate));
				linkInfo.TrackClicks = Convert.ToBoolean(Null.SetNull(dr["TrackClicks"], linkInfo.TrackClicks));
				linkInfo.NewWindow = Convert.ToBoolean(Null.SetNull(dr["NewWindow"], linkInfo.NewWindow));
			}

			return linkInfo;
		}

		private System.Collections.ArrayList FillLinks(System.Data.IDataReader dr)
		{
			ArrayList linkInfoList = new ArrayList();

			while (dr.Read()) {
				LinkInfo linkInfo = new LinkInfo();
				linkInfo.ItemId = Convert.ToInt32(Null.SetNull(dr["ItemId"], linkInfo.ItemId));
				linkInfo.ModuleId = Convert.ToInt32(Null.SetNull(dr["ModuleId"], linkInfo.ModuleId));
				linkInfo.Title = Convert.ToString(Null.SetNull(dr["Title"], linkInfo.Title));
				linkInfo.Url = Convert.ToString(Null.SetNull(dr["URL"], linkInfo.Url));
				linkInfo.ViewOrder = Convert.ToInt32(Null.SetNull(dr["ViewOrder"], linkInfo.ViewOrder));
				linkInfo.Description = Convert.ToString(Null.SetNull(dr["Description"], linkInfo.Description));
				linkInfo.CreatedByUser = Convert.ToInt32(Null.SetNull(dr["CreatedByUser"], linkInfo.CreatedByUser));
				linkInfo.CreatedDate = Convert.ToDateTime(Null.SetNull(dr["CreatedDate"], linkInfo.CreatedDate));
				linkInfo.TrackClicks = Convert.ToBoolean(Null.SetNull(dr["TrackClicks"], linkInfo.TrackClicks));
				linkInfo.NewWindow = Convert.ToBoolean(Null.SetNull(dr["NewWindow"], linkInfo.NewWindow));
				linkInfoList.Add(linkInfo);
			}

			return linkInfoList;
		}


		#endregion

		#region "Optional Interfaces"

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// GetSearchItems implements the ISearchable Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
		/// <history>
		///		[cnurse]	11/17/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public SearchItemInfoCollection GetSearchItems(Entities.Modules.ModuleInfo ModInfo)
		{
			SearchItemInfoCollection SearchItemCollection = new SearchItemInfoCollection();

			ArrayList links = GetLinks(ModInfo.ModuleID);

               foreach (object objLink in links)
               {
				SearchItemInfo SearchItem;
				{
					SearchItem = new SearchItemInfo(ModInfo.ModuleTitle + " - " + ((LinkInfo)objLink).Title, ((LinkInfo)objLink).Description, ((LinkInfo)objLink).CreatedByUser, ((LinkInfo)objLink).CreatedDate, ModInfo.ModuleID, ((LinkInfo)objLink).ItemId.ToString(), ((LinkInfo)objLink).Description, "ItemId=" + ((LinkInfo)objLink).ItemId.ToString(), Null.NullInteger);
					SearchItemCollection.Add(SearchItem);
				}
			}

			return SearchItemCollection;
		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// ExportModule implements the IPortable ExportModule Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModuleID">The Id of the module to be exported</param>
		/// <history>
		///		[cnurse]	11/17/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public string ExportModule(int ModuleID)
		{
			StringBuilder sbXML = new StringBuilder();

			ArrayList arrLinks = GetLinks(ModuleID);
			if (arrLinks.Count != 0)
			{
				sbXML.Append("<links>");
                    foreach (LinkInfo objLink in arrLinks)
                    {
					sbXML.Append("<link>");
					sbXML.AppendFormat("<title>{0}</title>", XmlUtils.XMLEncode(objLink.Title));
                         sbXML.AppendFormat("<url>{0}</url>", XmlUtils.XMLEncode(objLink.Url));
                         sbXML.AppendFormat("<vieworder>{0}</vieworder>", XmlUtils.XMLEncode(objLink.ViewOrder.ToString()));
                         sbXML.AppendFormat("<description>{0}</description>", XmlUtils.XMLEncode(objLink.Description));
                         sbXML.AppendFormat("<newwindow>{0}</newwindow>", XmlUtils.XMLEncode(objLink.NewWindow.ToString()));
					sbXML.Append("</link>");
				}
				sbXML.Append("</links>");
			}
			return sbXML.ToString();
		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// ImportModule implements the IPortable ImportModule Interface
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <param name="ModuleID">The Id of the module to be imported</param>
		/// <history>
		///		[cnurse]	11/17/2004	documented
		/// </history>
		/// -----------------------------------------------------------------------------
		public void ImportModule(int ModuleID, string Content, string Version, int UserId)
		{
			XmlNode xmlLinks = Globals.GetContent(Content, "links");
               foreach (XmlNode xmlLink in xmlLinks.SelectNodes("link"))
               {
				LinkInfo objLink = new LinkInfo();
				objLink.ModuleId = ModuleID;
				objLink.Title = xmlLink["title"].InnerText;
				objLink.Url = Globals.ImportUrl(ModuleID, xmlLink["url"].InnerText);
				objLink.ViewOrder = int.Parse(xmlLink["vieworder"].InnerText);
				objLink.Description = xmlLink["description"].InnerText;
				objLink.NewWindow = bool.Parse(xmlLink["newwindow"].InnerText);
				objLink.CreatedByUser = UserId;
				AddLink(objLink);
			}

		}

		#endregion

	}

}
