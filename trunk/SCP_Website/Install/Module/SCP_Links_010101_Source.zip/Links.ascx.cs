using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CSharpNuke;
using CSharpNuke.Services.Exceptions;
using CSharpNuke.Services.Localization;
using CSharpNuke.UI.Utilities;

namespace CSharpNuke.Modules.Links
{
    public partial class Links : Entities.Modules.PortalModuleBase, Entities.Modules.IActionable
    {
        protected void Page_Load(object sender, EventArgs e)
        {           
            try
            {

                if (Settings["linkcontrol"] != null && Settings["linkcontrol"].ToString() == "D")
                {
                    pnlList.Visible = false;
                    pnlDropdown.Visible = true;
                }
                else
                {
                    pnlList.Visible = true;
                    pnlDropdown.Visible = false;
                }

                if (!Page.IsPostBack)
                {

                    LinkController objLinks = new LinkController();

                    if (Settings["linkcontrol"] != null && Settings["linkcontrol"].ToString() == "D")
                    {
                        if (IsEditable)
                        {
                            cmdEdit.Visible = true;
                        }
                        else
                        {
                            cmdEdit.Visible = false;
                        }
                        cmdGo.ToolTip = Localization.GetString("cmdGo");
                        if (Settings["displayinfo"] != null && Settings["displayinfo"].ToString() == "Y")
                        {
                            cmdInfo.Visible = true;
                        }
                        else
                        {
                            cmdInfo.Visible = false;
                        }
                        cmdInfo.ToolTip = Localization.GetString("cmdInfo", this.LocalResourceFile);
                        cboLinks.DataSource = objLinks.GetLinks(ModuleId);
                        cboLinks.DataBind();
                    }
                    else
                    {
                        if (Settings["linkview"] != null && Settings["linkview"].ToString() == "H")
                        {
                            lstLinks.RepeatDirection = RepeatDirection.Horizontal;
                        }
                        else
                        {
                            lstLinks.RepeatDirection = RepeatDirection.Vertical;
                        }
                        lstLinks.DataSource = objLinks.GetLinks(ModuleId);
                        lstLinks.DataBind();
                    }
                }
            }

            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void Page_Unload(object sender, EventArgs e)
        {
            if (Settings["linkcontrol"] != null && (Settings["linkcontrol"].ToString() == "D" | Settings["linkcontrol"].ToString() == "Y"))
            {
                DataCache.RemoveCache(CacheKey);
            }

            if (!IsPostBack)
            {
                DataCache.RemoveCache(CacheKey);
            }

        }

        protected void cmdEdit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if ((cboLinks.SelectedItem != null))
                {
                    Response.Redirect(EditUrl("ItemID", cboLinks.SelectedItem.Value), true);
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void cmdGo_Click(object sender, EventArgs e)
        {
            try
            {
                if ((cboLinks.SelectedItem != null))
                {
                    string strURL = "";

                    LinkController objLinks = new LinkController();

                    LinkInfo objLink = objLinks.GetLink(int.Parse(cboLinks.SelectedValue), ModuleId);
                    if ((objLink != null))
                    {
                        strURL = FormatURL(objLink.Url.ToString(), objLink.TrackClicks);
                    }

                    //use javascript to open a new window if the combobox link style is used
                    if ((objLink != null))
                    {
                        if (objLink.NewWindow == true)
                        {
                            Response.Write("<script language=javascript>window.open('" + strURL + "','_blank')</script>");
                        }
                        else
                        {
                            Response.Redirect(strURL, true);
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void cmdInfo_Click(object sender, EventArgs e)
        {
            try
            {
                if ((cboLinks.SelectedItem != null))
                {
                    LinkController objLinks = new LinkController();

                    LinkInfo objLink = objLinks.GetLink(int.Parse(cboLinks.SelectedItem.Value), ModuleId);
                    if ((objLink != null))
                    {
                        if (lblDescription.Text == string.Empty)
                        {
                            lblDescription.Text = HtmlDecode(objLink.Description.ToString());
                        }
                        else
                        {
                            lblDescription.Text = "";
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void lstLinks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lstLinks.Items[lstLinks.SelectedIndex].FindControl("pnlDescription").Visible = !lstLinks.Items[lstLinks.SelectedIndex].FindControl("pnlDescription").Visible;
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        /*public string EditUrl(string keyName, string keyValue)
        {
            return base.EditUrl(keyName, keyValue);
        }*/

        public string GetHyperLinkTarget(string dataItem)
        {
            string targetValue = Convert.ToBoolean(dataItem) ? "_blank" : "_self";
            return targetValue;
        }

        public bool DisplayInfo()
        {
            try
            {
                if (Settings["displayinfo"] != null && Settings["displayinfo"].ToString() == "Y")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);                
            }
            return false;
        }

        public string DisplayToolTip(string description)
        {
            try
            {
                if (Settings["displayinfo"] != null && Settings["displayinfo"] == null)
                {
                    // Option not set, use default value
                    return description;
                }
                if (Settings["displayinfo"] != null && Settings["displayinfo"].ToString() == "N")
                {
                    return description;
                }
                else
                {
                    return String.Empty;
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
                return String.Empty;
            }
        }

        public string FormatURL(string link, bool trackClicks)
        {

            return Common.Globals.LinkClick(link, TabId, ModuleId, trackClicks);

        }

        public string FormatIcon()
        {          
            if (Settings["icon"] != null && Settings["icon"].ToString() != "")
            {
                return Common.Globals.LinkClick(Settings["icon"].ToString(), TabId, ModuleId, false);
            }
            return String.Empty;
        }

        public bool DisplayIcon()
        {
            try
            {
                object testobj = Settings["icon"];
                if (Settings["icon"] != null && Settings["icon"].ToString() != "")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);                
            }
            return false;
        }

        public string HtmlDecode(string htmlValue)
        {
            string functionReturnValue = null;
            try
            {
                functionReturnValue = Server.HtmlDecode(htmlValue);
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
            return functionReturnValue;
        }

        public string NoWrap()
        {
            if (Settings["nowrap"] != null && Settings["nowrap"].ToString() == "W")
            {
                return string.Empty;
            }
            else
            {
                return "nowrap";
            }
        }
        
        #region IActionable Members

        public CSharpNuke.Entities.Modules.Actions.ModuleActionCollection ModuleActions
        {
            get
            {
                Entities.Modules.Actions.ModuleActionCollection Actions = new Entities.Modules.Actions.ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), false, Security.SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion
    }
}