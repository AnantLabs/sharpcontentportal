using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SharpContent.Services.Exceptions;


namespace SharpContent.Modules.Links
{
    public partial class Settings : Entities.Modules.ModuleSettingsBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public override void LoadSettings()
        {
            try
            {
                if ((Page.IsPostBack == false))
                {
                    if (TabModuleSettings["linkcontrol"] != null && TabModuleSettings["linkcontrol"].ToString() != "")
                    {
                        optControl.Items.FindByValue(TabModuleSettings["linkcontrol"].ToString()).Selected = true;
                    }
                    else
                    {
                        optControl.SelectedIndex = 0;
                        // list
                    }
                    if (TabModuleSettings["linkview"] != null && TabModuleSettings["linkview"].ToString() != "")
                    {
                        optView.Items.FindByValue(TabModuleSettings["linkview"].ToString()).Selected = true;
                    }
                    else
                    {
                        optView.SelectedIndex = 0;
                        // vertical
                    }
                    if (TabModuleSettings["displayinfo"] != null && TabModuleSettings["displayinfo"].ToString() != "")
                    {
                        optInfo.Items.FindByValue(TabModuleSettings["displayinfo"].ToString()).Selected = true;
                    }
                    else
                    {
                        optInfo.SelectedIndex = 1;
                    }
                    if (TabModuleSettings["icon"] != null && TabModuleSettings["icon"].ToString() != "")
                    {
                        ctlIcon.Url = TabModuleSettings["icon"].ToString();
                    }
                    if (TabModuleSettings["nowrap"] != null && TabModuleSettings["nowrap"].ToString() != "")
                    {
                        optNoWrap.Items.FindByValue(TabModuleSettings["nowrap"].ToString()).Selected = true;
                    }
                    else
                    {
                        optNoWrap.SelectedIndex = 1;
                    }
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        public override void UpdateSettings()
        {
            try
            {
                Entities.Modules.ModuleController objModules = new Entities.Modules.ModuleController();

                objModules.UpdateTabModuleSetting(TabModuleId, "linkcontrol", optControl.SelectedItem.Value);
                objModules.UpdateTabModuleSetting(TabModuleId, "linkview", optView.SelectedItem.Value);
                objModules.UpdateTabModuleSetting(TabModuleId, "displayinfo", optInfo.SelectedItem.Value);
                objModules.UpdateTabModuleSetting(TabModuleId, "icon", ctlIcon.Url);
                objModules.UpdateTabModuleSetting(TabModuleId, "nowrap", optNoWrap.SelectedItem.Value);
                SynchronizeModule();
            }

            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }
    }
}
