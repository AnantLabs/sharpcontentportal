//
// Sharp Content portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System.Collections.Specialized;
using System.Text;
using System.Xml;

using SharpContent;
using SharpContent.Common;
using SharpContent.Entities.Modules;

using SharpContent.Modules.IFrame.Data;
using SharpContent.Modules.IFrame.Domain;
using System.Collections;
using System;

namespace SharpContent.Modules.IFrame
{

	/// <summary>
	/// IFrame Module controller.
	/// </summary>
	/// <history>
	///     [flanakin]   03/16/2006     Genesis
	///     [flanakin]   03/17/2006     Added import/export support
	/// </history>
	public class Controller : IPortable
	{

		#region "| Fields |"

		protected const string RootElement = "iframe";
		protected const string ParameterGroupElement = "parameters";
		protected const string ParameterElement = "param";
		protected const string ParameterNameElement = "name";
		protected const string ParameterTypeElement = "type";
		protected const string ParameterArgumentElement = "argument";

		private DataProvider _dataProvider;

		#endregion


		#region "| Sub-Classes |"

		/// <summary>
		/// IFrame Module properties.
		/// </summary>
		/// <remarks>
		///     All properties will be used as <c>iframe</c> tag attributes unless preceded by the 
		///     <see cref="NotAnAttributePrefix"/> value.
		/// </remarks>
		/// <history>
		///     [flanakin]    03/16/2006     Genesis
		///     [flanakin]    04/04/2006     Added <see cref="Name"/> and <see cref="UrlParameter"/> 
		///                                  properties and updated other properties to match 
		///                                  <c>iframe</c> tag attribute names
		/// </history>
		public class Properties
		{

			public const string NotAnAttributePrefix = "x-";

			//Public Const UrlParameter As String = "x-url" 'removed!

			public const string Name = "name";
			public const string Source = "src";
			public const string Height = "height";
			public const string Width = "width";
			public const string CssStyle = "style";
			public const string OnLoad = "onload";
			public const string ToolTip = "title";
			public const string Scrolling = "scrolling";
			public const string Border = "frameborder";
			public const string AllowTransparency = "allowtransparency";

		}

		#endregion


		#region "| Import/Export |"

		/// <summary>
		/// Exports module settings.
		/// </summary>
		/// <param name="ModuleID">Unique identifier of the module to be exported.</param>
		public string ExportModule(int ModuleID)
		{

			// constants
			const string StartTagFormat = "<{0}>";
			const string EndTagFormat = "</{0}>";
			const string TagFormat = "<{0}>{1}</{0}>";

			// init vars
			ModuleController objController = new ModuleController();
			Hashtable objSettings = objController.GetModuleSettings(ModuleID);
			StringBuilder sbXml = new StringBuilder();
			IFrameParameterCollection colParameters;

			// start xml
			sbXml.AppendFormat(StartTagFormat, RootElement);

			// save all keys
			foreach (object key in objSettings.Keys) {
				sbXml.AppendFormat(TagFormat, key.ToString(), SharpContent.Common.Utilities.XmlUtils.XMLEncode(objSettings[key].ToString()));
			}

			// save all parameters
			sbXml.AppendFormat(StartTagFormat, ParameterGroupElement);
			colParameters = GetParameters(ModuleID);
			for (int i = 0; i <= colParameters.Count - 1; i++) {
				if (colParameters.Item(i).IsValid)
				{
					sbXml.AppendFormat(StartTagFormat, ParameterElement);
					sbXml.AppendFormat(TagFormat, ParameterNameElement, SharpContent.Common.Utilities.XmlUtils.XMLEncode(colParameters.Item(i).Name));
					sbXml.AppendFormat(TagFormat, ParameterTypeElement, SharpContent.Common.Utilities.XmlUtils.XMLEncode(Enum.GetName(colParameters.Item(i).Type.GetType(), colParameters.Item(i).Type)));
					if (colParameters.Item(i).IsArgumentRequired()) sbXml.AppendFormat(TagFormat, ParameterArgumentElement, SharpContent.Common.Utilities.XmlUtils.XMLEncode(colParameters.Item(i).TypeArgument)); 
					sbXml.AppendFormat(EndTagFormat, ParameterElement);
				}
			}
			sbXml.AppendFormat(EndTagFormat, ParameterGroupElement);

			// end xml
			sbXml.AppendFormat(EndTagFormat, RootElement);

			// return xml
			return sbXml.ToString();

		}


		/// <summary>
		/// Imports module settings.
		/// </summary>
		/// <param name="ModuleID">Unique identifier of the module to be exported.</param>
		/// <param name="Content">XML content to import.</param>
		/// <param name="Version">Version of the content being imported.</param>
		/// <param name="UserID">Unique identifier of the user importing the content.</param>
		public void ImportModule(int ModuleID, string Content, string Version, int UserID)
		{

			// init vars
			ModuleController objController = new ModuleController();
			XmlNode objXml = Globals.GetContent(Content, RootElement);

			// update settings
			for (int i = 0; i <= objXml.ChildNodes.Count - 1; i++) {
				// init vars
				XmlNode objNode = objXml.ChildNodes[i];
				string strKey = objNode.LocalName;

				// if not parameters node, save setting; otherwise, add to data store
				if (strKey != ParameterGroupElement)
				{
					// handle version conflicts
					switch (Version) {
						case "03.02.00":
							break;
						default:
							if (strKey == "border") strKey = Controller.Properties.Border; 
							break;
					}

					// update settings
					objController.UpdateModuleSetting(ModuleID, strKey, objNode.InnerText);
				}
				else
				{
					// loop thru parameters
					for (int j = 0; j <= objNode.ChildNodes.Count - 1; j++) {
						IFrameParameter objParam = new IFrameParameter();
						objParam.ModuleID = ModuleID;
						for (int k = 0; k <= objNode.ChildNodes[j].ChildNodes.Count - 1; k++) {
							XmlNode objParamPropertyNode = objNode.ChildNodes[j].ChildNodes[k];
							switch (objParamPropertyNode.LocalName) {
								case ParameterNameElement:
									objParam.Name = objParamPropertyNode.InnerText;
									break;
								case ParameterTypeElement:
									objParam.Type = IFrameParameter.ParseType(objParamPropertyNode.InnerText);
									break;
								case ParameterArgumentElement:
									objParam.TypeArgument = objParamPropertyNode.InnerText;
									break;
							}
						}

						// add param
						if (objParam.IsValid) AddParameter(objParam); 
					}
				}
			}

		}

		#endregion


		#region "| Data Access |"

		/// <summary>
		/// Gets the single instance of the current <see cref="DataProvider"/>.
		/// </summary>
		protected DataProvider DataProvider {
			get {
				if (this._dataProvider == null)
				{
					this._dataProvider = DataProvider.Instance;
				}
				return this._dataProvider;
			}
		}


		/// <summary>
		/// Creates a new <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
		public void AddParameter(IFrameParameter Parameter)
		{
			DataProvider.AddParameter(Parameter);
		}


		/// <summary>
		/// Retrieves an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
		public IFrameParameter GetParameter(IFrameParameter.UniqueKey Key)
		{
			return DataProvider.GetParameter(Key);
		}


		/// <summary>
		/// Retrieves a collection of <see cref="IFrameParameter/> objects from the data store.
		/// </summary>
		/// <param name="ModuleID">Module identifier.</param>
		public IFrameParameterCollection GetParameters(int ModuleID)
		{
			return DataProvider.GetParameters(ModuleID);
		}


		/// <summary>
		/// Updates an existing <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
		public void UpdateParameter(IFrameParameter Parameter)
		{
			DataProvider.UpdateParameter(Parameter);
		}


		/// <summary>
		/// Removes an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
		public void DeleteParameter(IFrameParameter.UniqueKey Key)
		{
			DataProvider.DeleteParameter(Key);
		}

		#endregion

	}
}

