//
// Sharp Content portal - http://www.sharpcontentportal.com
// Copyright (c) 2002-2006
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System;
using System.Web;
using SharpContent.Common;
using SharpContent.Entities.Users;

namespace SharpContent.Modules.IFrame.Domain
{

	/// <summary>
	/// Represents a querystring parameter for the IFrame module.
	/// </summary>
	/// <history>
	///     [flanakin]   04/08/2006     Genesis
	/// </history>
	public class IFrameParameter
	{

		#region "| Fields |"

		private IFrameParameter.UniqueKey _key;
		private int _moduleID;
		private string _name;
		private IFrameParameterType _type;
		private string _typeArgument;
		private char[] _invalidCharacters = "<>, ;\"'?&".ToCharArray();

		#endregion


		#region "| Initialization |"

		/// <summary>
		/// Instantiates a new instance of the <c>IFrameParameter</c> module.
		/// </summary>
		public IFrameParameter()
		{
			this._key = new IFrameParameter.UniqueKey();
			this._type = IFrameParameterType.StaticValue;
		}

		#endregion


		#region "| Sub-Classes |"

		/// <summary>
		/// Represents a unique <see cref="IFrameParameter"/>.
		/// </summary>
		public class UniqueKey
		{

			// fields
			private int _id = -1;

			/// <summary>
			/// Gets or sets the unique identifier
			/// </summary>
			public int ID {
				get { return this._id; }
				set { this._id = value; }
			}

			/// <summary>
			/// Gets a value indicating whether the <see cref="IFrameParameter"/> is new.
			/// </summary>
			public bool IsNew {
				get { return (this._id <= 0); }
			}
		}

		#endregion


		#region "| Properties |"

		#region "| Key |"

		/// <summary>
		/// Gets or sets the unique key.
		/// </summary>
		public UniqueKey Key {
			get { return this._key; }
			set { this._key = value; }
		}


		/// <summary>
		/// Gets or sets the unique identifier.
		/// </summary>
		public int ID {
			get { return Key.ID; }
			set { Key.ID = value; }
		}


		/// <summary>
		/// Gets a value indicating whether the object is new.
		/// </summary>
		public bool IsNew {
			get { return Key.IsNew; }
		}

		#endregion


		/// <summary>
		/// Gets or sets the module identifier.
		/// </summary>
		public int ModuleID {
			get { return this._moduleID; }
			set { this._moduleID = value; }
		}


		/// <summary>
		/// Gets or sets the parameter name.
		/// </summary>
		public string Name {
			get { return this._name; }
			set { this._name = value; }
		}


		/// <summary>
		/// Gets or sets the parameter type.
		/// </summary>
		public IFrameParameterType Type {
			get { return this._type; }
			set { this._type = value; }
		}


		/// <summary>
		/// Gets or sets the parameter type argument.
		/// </summary>
		/// <remarks>
		/// The parameter type argument varies in purpose and usage. For instance, the argument may 
		/// represent a value, querystring parameter name, or custom user profile property.
		/// </remarks>
		public string TypeArgument {
			get { return this._typeArgument; }
			set { this._typeArgument = value; }
		}


		/// <summary>
		/// Gets a value indicating whether the parameter is valid.
		/// </summary>
		public bool IsValid {
			get {
				// check name
				if (Name == null || Name.Length == 0 || Name.IndexOfAny(_invalidCharacters) != -1) return false; 
				return !IsArgumentRequired() | CStrN(TypeArgument).Length > 0;
			}
		}

		#endregion


		#region "| Methods [Public] |"

		/// <summary>
		/// Converts a string representation of a <see cref="IFrameParameterType"/> to its object value.
		/// </summary>
		/// <param name="Type">Value to convert.</param>
		public static IFrameParameterType ParseType(string Type)
		{
			IFrameParameterType objType;
			try {
				objType = (IFrameParameterType)Enum.Parse(typeof(IFrameParameterType), Type);
			}
			catch (Exception ex) {
				objType = IFrameParameterType.StaticValue;
			}
			return objType;
		}


		/// <summary>
		/// Converts the <see cref="Type"/> to a string value.
		/// </summary>
		public string ConvertTypeToString()
		{
			return Enum.GetName(Type.GetType(), Type);
		}


		/// <summary>
		/// Determines parameter value based on applied settings.
		/// </summary>
		public string GetValue()
		{
			// init vars
			bool ArgumentIsEmpty = (TypeArgument == null || TypeArgument.Length == 0);
			SharpContent.Security.PortalSecurity objSecurity = new SharpContent.Security.PortalSecurity();
			// get value based on type
			switch (Type) {

				case IFrameParameterType.StaticValue:
					// static
					return TypeArgument;

				case IFrameParameterType.PassThrough:
					// pass-thru parameter / Querystring
					if (ArgumentIsEmpty) return ""; 
					if ((HttpContext.Current != null))
					{
						string qString = CStrN(HttpContext.Current.Request.QueryString[TypeArgument]);
						return objSecurity.InputFilter(qString, Security.PortalSecurity.FilterFlag.NoMarkup | Security.PortalSecurity.FilterFlag.NoScripting);
					}

					break;

				case IFrameParameterType.FormPassThrough:
					// pass-thru parameter 
					if (ArgumentIsEmpty) return ""; 
					if ((HttpContext.Current != null))
					{
						string fString = CStrN(HttpContext.Current.Request.Form[TypeArgument]);
						return objSecurity.InputFilter(fString, Security.PortalSecurity.FilterFlag.NoMarkup | Security.PortalSecurity.FilterFlag.NoScripting);

					}

					break;

				case IFrameParameterType.PortalID:
					// portal id
					return Convert.ToString(Globals.GetPortalSettings().PortalId);

				case IFrameParameterType.PortalName:
					// portal name
                        return Convert.ToString(Globals.GetPortalSettings().PortalName);

				case IFrameParameterType.TabID:
					// active tab id
                        return Convert.ToString(Globals.GetPortalSettings().ActiveTab.TabID);

				default:
					// user property
					// get current user
					UserInfo objUser = UserController.GetCurrentUserInfo();

					// handle user property
					switch (Type) {

						case IFrameParameterType.UserCustomProperty:
							// custom property
							if (ArgumentIsEmpty) return ""; 
							return objUser.Profile.GetPropertyValue(TypeArgument);

                              case IFrameParameterType.UserAccountNumber:
                                  return Convert.ToString(objUser.AccountNumber);

						case IFrameParameterType.UserID:
							return Convert.ToString(objUser.UserID);

						case IFrameParameterType.UserUsername:
							return objUser.Username;

						case IFrameParameterType.UserFirstName:
							return objUser.FirstName;

						case IFrameParameterType.UserLastName:
							return objUser.LastName;

						case IFrameParameterType.UserFullName:
							return objUser.DisplayName;

						case IFrameParameterType.UserEmail:
							return objUser.Membership.Email;

						case IFrameParameterType.UserWebsite:
							return objUser.Profile.Website;

						case IFrameParameterType.UserIM:
							return objUser.Profile.IM;

						case IFrameParameterType.UserStreet:
							return objUser.Profile.Street;

						case IFrameParameterType.UserUnit:
							return objUser.Profile.Unit;

						case IFrameParameterType.UserCity:
							return objUser.Profile.City;

						case IFrameParameterType.UserCountry:
							return objUser.Profile.Country;

						case IFrameParameterType.UserRegion:
							return objUser.Profile.Region;

						case IFrameParameterType.UserPostalCode:
							return objUser.Profile.PostalCode;

						case IFrameParameterType.UserPhone:
							return objUser.Profile.Telephone;

						case IFrameParameterType.UserCell:
							return objUser.Profile.Cell;

						case IFrameParameterType.UserFax:
							return objUser.Profile.Fax;

						case IFrameParameterType.UserLocale:
							return objUser.Profile.PreferredLocale;

						case IFrameParameterType.UserTimeZone:
							return Convert.ToString(objUser.Profile.TimeZone);

						case IFrameParameterType.UserIsAuthorized:
							return Convert.ToString(objUser.Membership.Approved);

						case IFrameParameterType.UserIsLockedOut:
							return Convert.ToString(objUser.Membership.LockedOut);

						case IFrameParameterType.UserIsSuperUser:
							return Convert.ToString(objUser.IsSuperUser);

					}
					break;

			}

			return "";
		}





		/// <summary>
		/// Determines whether the <see cref="TypeArgument"/> is required based on the <see cref="Type"/>.
		/// </summary>
		public bool IsArgumentRequired()
		{
			switch (Type) {
				case IFrameParameterType.StaticValue:
				case IFrameParameterType.PassThrough:
				case IFrameParameterType.UserCustomProperty:
				case IFrameParameterType.FormPassThrough:
					return true;
				default:
					return false;
			}
		}


		/// <summary>
		/// Determines parameter value based on applied settings.
		/// </summary>
		public override string ToString()
		{
			// if valid, return formatted parameter; otherwise, return empty string
			if (IsValid)
			{
				return string.Format("{0}={1}", Name, HttpUtility.UrlEncode(GetValue()));
			}
			else
			{
				return "";
			}
		}

		#endregion

		#region "Helper Functions"
		public string CStrN(object value, string defaultValue)
		{
              if (value == null) return defaultValue;
              if (object.ReferenceEquals(value, DBNull.Value)) return defaultValue;
              if ((string)value == "") return defaultValue; 
		    return (string)value;
		}
         
          public string CStrN(object value)
          {
              if (value == null) return String.Empty;
              if (object.ReferenceEquals(value, DBNull.Value)) return String.Empty;
              if ((string)value == "") return String.Empty;
              return (string)value;
          }
		#endregion





	}
}

