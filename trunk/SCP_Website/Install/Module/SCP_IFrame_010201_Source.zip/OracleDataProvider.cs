//
// CSharpNuke® - http://www.csharpnuke.com
// Copyright (c) 2002-2005
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Configuration;
using System.Data;
using Oracle.DataAccess.Client;

using Microsoft.ApplicationBlocks.Data;

using CSharpNuke.Common.Utilities;
using CSharpNuke.Framework.Providers;

using CSharpNuke.Modules.IFrame.Data;
using CSharpNuke.Modules.IFrame.Domain;

namespace CSharpNuke.Modules.IFrame
{

	/// <summary>
	/// IFrame Module data provider for Oracle Server.
	/// </summary>
	/// <history>
	///     [flanakin]   04/08/2006     Genesis
	/// </history>
	public class OracleDataProvider : DataProvider
	{

		#region "| Fields |"

		// provider constants
		private const string objectPrefix = "IFrame_";
		private const string connectionStringProperty = "connectionString";
		private const string connectionStringNameProperty = "connectionStringName";
		private const string providerPathProperty = "providerPath";
		private const string packageNameProperty = "packageName";
		private const string databaseOwnerProperty = "databaseOwner";

		// sproc constants
		private const string addParamProc = "AddParameter";
		private const string getParamProc = "GetParameter";
		private const string getParamsProc = "GetParameters";
		private const string updateParamProc = "UpdateParameter";
		private const string deleteParamProc = "DeleteParameter";

		// private
		private ProviderConfiguration _providerConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType);
		private string _connectionString;
		private string _providerPath;
          private string _packageName;
		private string _databaseOwner;

		#endregion


		#region "| Initialization |"

		/// <summary>
		/// Instantiates a new instance of the <c>SqlDataProvider</c> class.
		/// </summary>
          public OracleDataProvider()
		{
			// init vars
			Provider objProvider = (Provider)this._providerConfiguration.Providers[this._providerConfiguration.DefaultProvider];

			// conn string
			//Get Connection string from web.config
			_connectionString = Config.GetConnectionString();

			if (_connectionString == "")
			{
				// Use connection string specified in provider
				_connectionString = objProvider.Attributes["connectionString"];
			}

			// path
			this._providerPath = objProvider.Attributes[providerPathProperty];

			// package
               _packageName = "csn_iframe_pkg.csn_";

			// dbo
			this._databaseOwner = objProvider.Attributes[databaseOwnerProperty];
			if (this._databaseOwner != "" && !this._databaseOwner.EndsWith(".")) this._databaseOwner += "."; 
		}

		#endregion


		#region "| Properties |"

		/// <summary>
		/// Gets the connection string.
		/// </summary>
		public string ConnectionString {
			get { return this._connectionString; }
		}


		/// <summary>
		/// Gets the provider path.
		/// </summary>
		public string ProviderPath {
			get { return this._providerPath; }
		}


		/// <summary>
		/// Gets the object qualifier.
		/// </summary>
          public string PackageName
          {
			get { return this._packageName; }
		}


		/// <summary>
		/// Gets the database owner.
		/// </summary>
		public string DatabaseOwner {
			get { return this._databaseOwner; }
		}

		#endregion


		#region "| Methods [Public] |"

		/// <summary>
		/// Creates a new <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
		public override void AddParameter(IFrameParameter parameter)
		{
              OracleParameter[] parms = {
		        new OracleParameter("i_moduleid", OracleDbType.Int32), 
		        new OracleParameter("i_name", OracleDbType.Varchar2), 
		        new OracleParameter("i_type", OracleDbType.Varchar2), 
		        new OracleParameter("i_argument", OracleDbType.NVarchar2)};
              parms[0].Direction = ParameterDirection.Input;
              parms[0].Value = parameter.ModuleID;
              parms[1].Direction = ParameterDirection.Input;
              parms[1].Value = parameter.Name;
              parms[2].Direction = ParameterDirection.Input;
              parms[2].Value = parameter.Type;
              parms[3].Direction = ParameterDirection.Input;
              parms[3].Value = parameter.TypeArgument;

              OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "IFRAME_ADDPARAMETER", parms);
		}

		/// <summary>
		/// Retrieves an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
         public override IFrameParameter GetParameter(IFrameParameter.UniqueKey key)
         {
             // init vars
             OracleParameter[] parms = {
		        new OracleParameter("i_parameterid", OracleDbType.Int32), 
		        new OracleParameter("o_rc1", OracleDbType.RefCursor)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = key.ID;
             parms[1].Direction = ParameterDirection.Output;

             IDataReader objReader = OracleHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "IFRAME_GETPARAMETER", parms);
             IFrameParameter objParam = new IFrameParameter();

             // loop thru data
             while (objReader.Read())
             {
                 objParam.ID = objReader.GetInt32(0);
                 objParam.ModuleID = objReader.GetInt32(1);
                 objParam.Name = objReader.GetString(2);
                 objParam.Type = IFrameParameter.ParseType(objReader.GetString(3));
                 objParam.TypeArgument = objReader.GetString(4);
             }
             objReader.Close();

             // return
             return objParam;
         }


		/// <summary>
		/// Retrieves a collection of <see cref="IFrameParameter/> objects from the data store.
		/// </summary>
		/// <param name="ModuleID">Module identifier.</param>
         public override IFrameParameterCollection GetParameters(int i_moduleid)
         {
             // init vars
             OracleParameter[] parms = {
		        new OracleParameter("i_moduleid", OracleDbType.Int32), 
		        new OracleParameter("o_rc1", OracleDbType.RefCursor)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = i_moduleid;
             parms[1].Direction = ParameterDirection.Output;

             IDataReader objReader = OracleHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "IFRAME_GETPARAMETERS", parms);
             IFrameParameterCollection colParams = new IFrameParameterCollection();

             // loop thru data
             while (objReader.Read())
             {
                 IFrameParameter objParam = new IFrameParameter();
                 objParam.ID = Convert.ToInt32(objReader.GetValue(0));
                 objParam.ModuleID = Convert.ToInt32(objReader.GetValue(1));
                 objParam.Name = objReader.GetString(2);
                 objParam.Type = IFrameParameter.ParseType(objReader.GetString(3));
                 if (!objReader.IsDBNull(4)) objParam.TypeArgument = objReader.GetString(4);
                 colParams.Add(objParam);
             }
             objReader.Close();

             // return
             return colParams;
         }


		/// <summary>
		/// Updates an existing <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
         public override void UpdateParameter(IFrameParameter parameter)
         {
             OracleParameter[] parms = {
		        new OracleParameter("i_parameterid", OracleDbType.Int32), 
		        new OracleParameter("i_name", OracleDbType.Varchar2), 
		        new OracleParameter("i_type", OracleDbType.Varchar2), 
		        new OracleParameter("i_argument", OracleDbType.NVarchar2)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = parameter.ID;
             parms[1].Direction = ParameterDirection.Input;
             parms[1].Value = parameter.Name;
             parms[2].Direction = ParameterDirection.Input;
             parms[2].Value = parameter.Type;
             parms[3].Direction = ParameterDirection.Input;
             parms[3].Value = parameter.TypeArgument;
             
             OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "IFRAME_UPDATEPARAMETER", parms);
         }


		/// <summary>
		/// Removes an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
         public override void DeleteParameter(IFrameParameter.UniqueKey key)
         {
             OracleParameter[] parms = {
		        new OracleParameter("i_parameterid", OracleDbType.Int32)};
             parms[0].Direction = ParameterDirection.Input;
             parms[0].Value = key.ID;

             OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DatabaseOwner + PackageName + "IFRAME_DELETEPARAMETER", parms);
         }

		#endregion


		#region "| Methods [Private] |"

		/// <summary>
		/// Returns the fully-qualified database object name.
		/// </summary>
		/// <param name="Name">Base object name.</param>
		private string GetName(string Name)
		{
			return DatabaseOwner + PackageName + objectPrefix + Name;
		}


		/// <summary>
		/// Returns <see cref="DBNull.Value"/> if <paramref name="Value"/> is null.
		/// </summary>
		/// <param name="Value">Object to evaluate.</param>
		private object GetNull(object Value)
		{
			return Null.GetNull(Value, DBNull.Value);
		}

		#endregion

	}
}

