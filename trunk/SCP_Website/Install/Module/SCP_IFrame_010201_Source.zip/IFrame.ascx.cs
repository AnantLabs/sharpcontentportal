using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CSharpNuke.Entities.Modules;
using CSharpNuke.Entities.Modules.Actions;
using CSharpNuke.Services.Localization;
using CSharpNuke.Modules.IFrame.Domain;
using CSharpNuke.Services.Exceptions;
using CSharpNuke.Security;

namespace CSharpNuke.Modules.IFrame
{
    public partial class IFrame : PortalModuleBase, IActionable
    {
        public const string SupportKey = "Support";

        //protected HtmlGenericControl htmIFrame;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                // get default
                string strSource = Convert.ToString(Settings[Controller.Properties.Source]);
                IFrameParameterCollection colParams = (new Controller()).GetParameters(ModuleId);

                // if source is specified
                if (strSource != "")
                {
                    // prepend portal directory
                    if (strSource.IndexOf("://") < 0 && !strSource.StartsWith("/"))
                    {
                        strSource = PortalSettings.HomeDirectory + strSource;
                    }

                    // append dynamic parameters
                    if (colParams.Count > 0)
                    {
                        strSource += (strSource.IndexOf("?") == -1 ? "?" : "&").ToString() + colParams.ToString();
                    }

                    // add source and unsupported text
                    htmIFrame.Attributes.Add(Controller.Properties.Source, strSource);
                    htmIFrame.InnerText = Localization.GetString(SupportKey, this.LocalResourceFile);

                    // add attributes
                    foreach (object key in Settings.Keys)
                    {
                        // if valid attribute, setting has value, and the attribute hasn't already been added...
                        if (!Convert.ToString(key).StartsWith(Controller.Properties.NotAnAttributePrefix) && Convert.ToString(Settings[key]) != "" && Convert.ToString(key) != Controller.Properties.Source)
                        {
                            htmIFrame.Attributes.Add(Convert.ToString(key), Convert.ToString(Settings[key]));
                        }
                    }
                }
                else
                {
                    htmIFrame.Visible = false;
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }

        }

        #region IActionable Members

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection actions = new ModuleActionCollection();
                actions.Add(GetNextActionID(), Localization.GetString(ModuleActionType.AddContent, LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return actions;
            }
        }

        #endregion
    }
}
