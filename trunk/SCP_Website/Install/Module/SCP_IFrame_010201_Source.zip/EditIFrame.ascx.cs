using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CSharpNuke.Entities.Modules;
using CSharpNuke.Modules.IFrame.Domain;
using CSharpNuke.Services.Exceptions;
using CSharpNuke.Services.Localization;
using CSharpNuke.UI.Utilities;
using CSharpNuke.UI.Skins.Controls;

namespace CSharpNuke.Modules.IFrame
{
    sealed class Constants
    {
        public const string TableHeadScope = "scope";
        public const string TableHeadRowScope = "row";
        public const string TableHeadColScope = "col";
    }

    sealed class ControlNames
    {
        public const string ParameterDeleteButton = "cmdDeleteParam";
        public const string ParameterNameLabel = "lblParamName";
        public const string ParameterName = "txtParamName";
        public const string ParameterTypeLabel = "lblParamType";
        public const string ParameterType = "cboParamType";
        public const string ParameterArgumentLabel = "lblParamArgument";
        public const string ParameterArgument = "txtParamArgument";
        public const string ParameterScript = "lblParamScript";
    }

    sealed class LocaleKeys
    {
        public const string ParameterNameHeader = "Name.Header";
        public const string ParameterTypeHeader = "Type.Header";
        public const string ParameterArgumentHeader = "Argument.Header";
        public const string ParameterDeleteConfirmation = "DeleteParamConfirmation";
        public const string ParameterType = "txtParamType";
        public const string ParameterArgument = "txtParamArgument";
        public const string ParameterInvalidHeader = "ParameterInvalid.Header";
        public const string ParameterInvalid = "ParameterInvalid";
    }

    public partial class EditIFrame : PortalModuleBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack && ModuleId > 0)
                {
                    //localize(grid)
                    Localization.LocalizeGridView(ref grdParams, this.LocalResourceFile);
                    BindData();
                }
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowCreated(object sender, GridViewRowEventArgs e)
        {
            try
            {
                // add delete confirmation
                Control cmdDeleteParam = e.Row.FindControl(ControlNames.ParameterDeleteButton);
                if ((cmdDeleteParam != null))
                {
                    ClientAPI.AddButtonConfirm((WebControl)cmdDeleteParam, Localization.GetString(LocaleKeys.ParameterDeleteConfirmation, this.LocalResourceFile));
                }

                // add accessible column headers
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    e.Row.Cells[1].Attributes.Add(Constants.TableHeadScope, Constants.TableHeadColScope);
                    e.Row.Cells[2].Attributes.Add(Constants.TableHeadScope, Constants.TableHeadColScope);
                }
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                const string LabelFormat = "<label style=\"display:none;\" for=\"{0}\">{1}</label>";
                DataControlRowState objItemState = e.Row.RowState;
                if (objItemState == DataControlRowState.Edit)
                {
                    Label ctlLabel;
                    Control ctlSetting;
                    string strTypeID;
                    string strArgID;

                    // name
                    ctlLabel = (Label)e.Row.FindControl(ControlNames.ParameterNameLabel);
                    ctlSetting = e.Row.FindControl(ControlNames.ParameterName);
                    ctlLabel.Text = string.Format(LabelFormat, ctlSetting.ClientID.ToString(), Localization.GetString(LocaleKeys.ParameterNameHeader, LocalResourceFile));

                    // type - also add javascript to show/hide arg textbox
                    ctlLabel = (Label)e.Row.FindControl(ControlNames.ParameterTypeLabel);
                    ctlSetting = e.Row.FindControl(ControlNames.ParameterType);
                    ctlLabel.Text = string.Format(LabelFormat, ctlSetting.ClientID.ToString(), Localization.GetString(LocaleKeys.ParameterTypeHeader, LocalResourceFile));
                    strTypeID = ctlSetting.ClientID;
                    ((WebControl)ctlSetting).Attributes.Add("onblur", "iframe_showArgument();");
                    ((WebControl)ctlSetting).Attributes.Add("onchange", "iframe_showArgument();");

                    // argument - also add javascript to set default visiblity based on type
                    ctlLabel = (Label)e.Row.FindControl(ControlNames.ParameterArgumentLabel);
                    ctlSetting = e.Row.FindControl(ControlNames.ParameterArgument);
                    ctlLabel.Text = string.Format(LabelFormat, ctlSetting.ClientID.ToString(), Localization.GetString(LocaleKeys.ParameterArgumentHeader, LocalResourceFile));
                    strArgID = ctlSetting.ClientID;

                    // add javascript
                    ctlLabel = (Label)e.Row.FindControl(ControlNames.ParameterScript);
                    ctlLabel.Text = "<script type=\"text/javascript\">iframe_showArgument();function iframe_showArgument(){document.getElementById('" + strArgID + "').style.display=((document.getElementById('" + strTypeID + "').selectedIndex<4)?'inline':'none');}</script>";
                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                // init vars
                IFrameParameter objParam = new IFrameParameter();

                // set values
                if (e.RowIndex > -1) objParam.ID = Convert.ToInt32(grdParams.DataKeys[e.RowIndex].Value);
                objParam.ModuleID = ModuleId;
                objParam.Name = ((TextBox)grdParams.Rows[e.RowIndex].FindControl(ControlNames.ParameterName)).Text;
                objParam.Type = IFrameParameter.ParseType(((DropDownList)grdParams.Rows[e.RowIndex].FindControl(ControlNames.ParameterType)).SelectedValue);
                if (objParam.IsArgumentRequired()) objParam.TypeArgument = ((TextBox)grdParams.Rows[e.RowIndex].FindControl(ControlNames.ParameterArgument)).Text;

                // add/update param
                if (objParam.IsValid)
                {
                    Controller objController = new Controller();
                    if (objParam.IsNew)
                    {
                        objController.AddParameter(objParam);
                    }
                    else
                    {
                        objController.UpdateParameter(objParam);
                    }
                }


                else
                {
                    CSharpNuke.UI.Skins.Skin.AddModuleMessage(this, Localization.GetString(LocaleKeys.ParameterInvalidHeader, LocalResourceFile), Localization.GetString(LocaleKeys.ParameterInvalid, LocalResourceFile), ModuleMessageType.RedError);
                }
                // clear edit row
                grdParams.EditIndex = -1;
                // bind data
                BindData();
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowEditing(object sender, GridViewEditEventArgs e)
        {
            try
            {
                SaveParameterEditRow(sender, grdParams);
                grdParams.EditIndex = e.NewEditIndex;
                grdParams.SelectedIndex = -1;
                BindData();
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                // init vars
                Controller objController = new Controller();
                IFrameParameter.UniqueKey objParamKey = new IFrameParameter.UniqueKey();

                // assign key values
                objParamKey.ID = Convert.ToInt32(grdParams.DataKeys[e.RowIndex].Value);

                // delete parameter
                objController.DeleteParameter(objParamKey);

                // reset edit row
                grdParams.EditIndex = -1;
                BindData();
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void grdParams_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            try
            {
                grdParams.EditIndex = -1;
                BindData();
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void cmdAddParam_Click(object sender, EventArgs e)
        {
            try
            {
                // save edit row
                SaveParameterEditRow(sender, cmdAddParam);

                // add item
                grdParams.EditIndex = -1;
                BindData(true);
            }
            catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void cmdSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {

                    // update settings
                    ModuleController objController = new ModuleController();
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Source, urlSource.Url);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Name, txtName.Text);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Height, txtHeight.Text);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Width, txtWidth.Text);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.CssStyle, txtCssStyle.Text);
                    if (IsAdmin) objController.UpdateModuleSetting(ModuleId, Controller.Properties.OnLoad, txtOnload.Text);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Scrolling, cboScrolling.SelectedValue);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.Border, cboBorder.SelectedValue);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.ToolTip, txtToolTip.Text);
                    objController.UpdateModuleSetting(ModuleId, Controller.Properties.AllowTransparency, cbAllowTransparency.Checked.ToString());
                    // return to view control
                    Response.Redirect(CSharpNuke.Common.Globals.NavigateURL(), true);

                }
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected void cmdCancel_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect(CSharpNuke.Common.Globals.NavigateURL(), true);
            }
            catch (Exception exc)
            {
                //Module failed to load
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected string GetIFrameParameterName(object dataItem)
        {
            return ((IFrameParameter)dataItem).Name;
        }

        protected string GetIFrameParameterIsArgumentRequired(object dataItem)
        {
            string typeArg = ((IFrameParameter)dataItem).IsArgumentRequired() ? "(" + Convert.ToString(((IFrameParameter)dataItem).TypeArgument) + ")" : String.Empty;
            return typeArg;
        }

        protected string GetIFrameParameterTypeToString(object dataItem)
        {
            return ((IFrameParameter)dataItem).ConvertTypeToString();
        }

        protected int GetIFrameParameterType(object dataItem)
        {
            return Convert.ToInt32(((IFrameParameter)dataItem).Type);
        }

        protected string GetIFrameParameterTypeArgument(object dataItem)
        {
            return ((IFrameParameter)dataItem).TypeArgument;
        }

        private void SaveParameterEditRow(object originalSender, object trigger)
        {
            if (grdParams.EditIndex > -1)
            {
                GridViewUpdateEventArgs ie = new GridViewUpdateEventArgs(grdParams.EditIndex);
                grdParams_RowUpdating(originalSender, ie);
            }
        }

        private void BindData(bool ShowAddParamRow)
        {
            BindSettings();
            BindParameters(ShowAddParamRow);
        }

        private void BindData()
        {
            BindSettings();
            BindParameters(false);
        }

        private void BindSettings()
        {
            urlSource.Url = (string)Settings[Controller.Properties.Source];
            txtName.Text = (string)Settings[Controller.Properties.Name];
            txtHeight.Text = (string)Settings[Controller.Properties.Height];
            txtWidth.Text = (string)Settings[Controller.Properties.Width];
            txtCssStyle.Text = (string)Settings[Controller.Properties.CssStyle];
            txtOnload.Enabled = IsAdmin;
            txtOnload.Text = (string)Settings[Controller.Properties.OnLoad];
            txtToolTip.Text = (string)Settings[Controller.Properties.ToolTip];
            if ((string)Settings[Controller.Properties.Scrolling] != "")
            {
                try
                {
                    cboScrolling.SelectedValue = (string)Settings[Controller.Properties.Scrolling];
                }
                catch
                {
                }
            }
            if ((string)Settings[Controller.Properties.Border] != "")
            {
                try
                {
                    cboBorder.SelectedValue = (string)Settings[Controller.Properties.Border];
                }
                catch
                {
                }
            }
            if ((string)Settings[Controller.Properties.AllowTransparency] != "")
            {
                try
                {
                    cbAllowTransparency.Checked = bool.Parse((string)Settings[Controller.Properties.AllowTransparency]);
                }
                catch
                {
                }
            }

        }

        private void BindParameters(bool ShowAddRow)
        {
            Controller objController = new Controller();
            IFrameParameterCollection colParams = objController.GetParameters(ModuleId);

            // add new row
            if (ShowAddRow)
            {
                colParams.Add(new IFrameParameter());
                grdParams.EditIndex = colParams.Count - 1;
            }

            //

            // apply data source
            grdParams.DataSource = colParams;
            grdParams.DataBind();
            grdParams.Visible = (colParams.Count > 0 || ShowAddRow);

            // bind settings
            BindSettings();
        }

        private void BindParameters()
        {
            Controller objController = new Controller();
            IFrameParameterCollection colParams = objController.GetParameters(ModuleId);

            // add new row            
            colParams.Add(new IFrameParameter());
            grdParams.EditIndex = colParams.Count - 1;
            

            // apply data source
            grdParams.DataSource = colParams;
            grdParams.DataBind();
            grdParams.Visible = (colParams.Count > 0 || false);

            // bind settings
            BindSettings();
        }

        private bool IsAdmin
        {
            get { return UserInfo.IsInRole(this.PortalSettings.AdministratorRoleName) | UserInfo.IsSuperUser; }
        }
    }
}
