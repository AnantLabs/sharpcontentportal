//
// Sharp Content portal - http://www.sharpcontentportal.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using SharpContent.ApplicationBlocks.Data;

using SharpContent.Common.Utilities;
using SharpContent.Framework.Providers;

using SharpContent.Modules.IFrame.Data;
using SharpContent.Modules.IFrame.Domain;

namespace SharpContent.Modules.IFrame
{

	/// <summary>
	/// IFrame Module data provider for Microsoft SQL Server.
	/// </summary>
	/// <history>
	///     [flanakin]   04/08/2006     Genesis
	/// </history>
	public class SqlDataProvider : DataProvider
	{

		#region "| Fields |"

		// provider constants
		private const string ObjectPrefix = "IFrame_";
		private const string ConnectionStringProperty = "connectionString";
		private const string ConnectionStringNameProperty = "connectionStringName";
		private const string ProviderPathProperty = "providerPath";
		private const string ObjectQualifierProperty = "objectQualifier";
		private const string DatabaseOwnerProperty = "databaseOwner";

		// sproc constants
		private const string AddParamProc = "AddParameter";
		private const string GetParamProc = "GetParameter";
		private const string GetParamsProc = "GetParameters";
		private const string UpdateParamProc = "UpdateParameter";
		private const string DeleteParamProc = "DeleteParameter";

		// private
		private ProviderConfiguration _providerConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType);
		private string _connectionString;
		private string _providerPath;
		private string _objectQualifier;
		private string _databaseOwner;

		#endregion


		#region "| Initialization |"

		/// <summary>
		/// Instantiates a new instance of the <c>SqlDataProvider</c> class.
		/// </summary>
		public SqlDataProvider()
		{
			// init vars
			Provider objProvider = (Provider)this._providerConfiguration.Providers[this._providerConfiguration.DefaultProvider];

			// conn string
			//Get Connection string from web.config
			_connectionString = Config.GetConnectionString();

			if (_connectionString == "")
			{
				// Use connection string specified in provider
				_connectionString = objProvider.Attributes["connectionString"];
			}

			// path
			this._providerPath = objProvider.Attributes[ProviderPathProperty];

			// qualifier
			this._objectQualifier = objProvider.Attributes[ObjectQualifierProperty];
			if (this._objectQualifier != "" && !this._objectQualifier.EndsWith("_")) this._objectQualifier += "_"; 

			// dbo
			this._databaseOwner = objProvider.Attributes[DatabaseOwnerProperty];
			if (this._databaseOwner != "" && !this._databaseOwner.EndsWith(".")) this._databaseOwner += "."; 
		}

		#endregion


		#region "| Properties |"

		/// <summary>
		/// Gets the connection string.
		/// </summary>
		public string ConnectionString {
			get { return this._connectionString; }
		}


		/// <summary>
		/// Gets the provider path.
		/// </summary>
		public string ProviderPath {
			get { return this._providerPath; }
		}


		/// <summary>
		/// Gets the object qualifier.
		/// </summary>
		public string ObjectQualifier {
			get { return this._objectQualifier; }
		}


		/// <summary>
		/// Gets the database owner.
		/// </summary>
		public string DatabaseOwner {
			get { return this._databaseOwner; }
		}

		#endregion


		#region "| Methods [Public] |"

		/// <summary>
		/// Creates a new <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
		public override void AddParameter(IFrameParameter Parameter)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, GetName(AddParamProc), Parameter.ModuleID, Parameter.Name, Parameter.Type, Parameter.TypeArgument);
		}


		/// <summary>
		/// Retrieves an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
		public override IFrameParameter GetParameter(IFrameParameter.UniqueKey Key)
		{
			// init vars
			IDataReader objReader = SqlHelper.ExecuteReader(ConnectionString, GetName(GetParamProc), Key.ID);
			IFrameParameter objParam = new IFrameParameter();

			// loop thru data
			while (objReader.Read())
			{
				objParam.ID = objReader.GetInt32(0);
				objParam.ModuleID = objReader.GetInt32(1);
				objParam.Name = objReader.GetString(2);
				objParam.Type = IFrameParameter.ParseType(objReader.GetString(3));
				objParam.TypeArgument = objReader.GetString(4);
			}
			objReader.Close();

			// return
			return objParam;
		}


		/// <summary>
		/// Retrieves a collection of <see cref="IFrameParameter/> objects from the data store.
		/// </summary>
		/// <param name="ModuleID">Module identifier.</param>
		public override IFrameParameterCollection GetParameters(int ModuleID)
		{
			// init vars
			IDataReader objReader = SqlHelper.ExecuteReader(ConnectionString, GetName(GetParamsProc), ModuleID);
			IFrameParameterCollection colParams = new IFrameParameterCollection();

			// loop thru data
			while (objReader.Read()) {
				IFrameParameter objParam = new IFrameParameter();
				objParam.ID = objReader.GetInt32(0);
				objParam.ModuleID = objReader.GetInt32(1);
				objParam.Name = objReader.GetString(2);
				objParam.Type = IFrameParameter.ParseType(objReader.GetString(3));
				if (!objReader.IsDBNull(4)) objParam.TypeArgument = objReader.GetString(4); 
				colParams.Add(objParam);
			}
			objReader.Close();

			// return
			return colParams;
		}


		/// <summary>
		/// Updates an existing <see cref="IFrameParameter/> object in the data store.
		/// </summary>
		/// <param name="Parameter">Parameter object.</param>
		public override void UpdateParameter(IFrameParameter Parameter)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, GetName(UpdateParamProc), Parameter.ID, Parameter.Name, Parameter.Type, Parameter.TypeArgument);
		}


		/// <summary>
		/// Removes an existing <see cref="IFrameParameter/> object from the data store.
		/// </summary>
		/// <param name="Key">Parameter identifier.</param>
		public override void DeleteParameter(IFrameParameter.UniqueKey Key)
		{
			SqlHelper.ExecuteNonQuery(ConnectionString, GetName(DeleteParamProc), Key.ID);
		}

		#endregion


		#region "| Methods [Private] |"

		/// <summary>
		/// Returns the fully-qualified database object name.
		/// </summary>
		/// <param name="Name">Base object name.</param>
		private string GetName(string Name)
		{
			return DatabaseOwner + ObjectQualifier + ObjectPrefix + Name;
		}


		/// <summary>
		/// Returns <see cref="DBNull.Value"/> if <paramref name="Value"/> is null.
		/// </summary>
		/// <param name="Value">Object to evaluate.</param>
		private object GetNull(object Value)
		{
			return Null.GetNull(Value, DBNull.Value);
		}

		#endregion

	}
}

