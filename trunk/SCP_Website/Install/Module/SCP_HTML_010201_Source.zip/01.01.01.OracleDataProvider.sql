/***************************************************************/
/*****              OracleDataProvider                     *****/
/*****                                                     *****/
/*****                                                     *****/
/***** Note: To manually execute this script you must      *****/
/*****       perform a search and replace operation        *****/
/*****       for {databaseOwner}                           *****/
/*****                                                     *****/
/***************************************************************/

/** Create Table **/

DECLARE 
  v_exists NUMBER(1,0);
BEGIN
  v_exists := 0;
  SELECT COUNT(*)
  INTO v_exists
  FROM user_tables
  WHERE LOWER(TABLE_NAME) = LOWER('CSN_HTMLTEXT');
  
  IF v_exists = 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'CREATE TABLE {databaseOwner}csn_HtmlText(
			ModuleID number(10,0) NOT NULL,
			DesktopHtml nclob NOT NULL,
			DesktopSummary nclob,
			CreatedByUser number(10,0),
			CreatedDate date) TABLESPACE CSWS_DBO_DATA01_128K';
      EXECUTE IMMEDIATE 'ALTER TABLE {databaseOwner}csn_HtmlText ADD (CONSTRAINT PK_CSN_HHTMLTEXT PRIMARY KEY (ModuleID) USING INDEX TABLESPACE CSWS_DBO_INDEX01_128K)';
      EXECUTE IMMEDIATE 'ALTER TABLE {databaseOwner}csn_HtmlText ADD (CONSTRAINT FK_CSN_HHTMLTEXT_CSN_MODULES FOREIGN KEY (ModuleID) REFERENCES {databaseOwner}csn_Modules (ModuleID) ON DELETE CASCADE)';
    END;
  END IF;
END;
/

CREATE OR REPLACE PACKAGE {databaseOwner}CSN_HTMLTEXT_PKG AUTHID CURRENT_USER AS
procedure csn_AddHtmlText(

	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
);
procedure csn_GetHtmlText (
	i_ModuleId in number,
        o_rc1      out {databaseOwner}global_pkg.rct1
);
procedure csn_UpdateHtmlText (
	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
);
end CSN_HTMLTEXT_PKG;
/

CREATE OR REPLACE PACKAGE BODY {databaseOwner}CSN_HTMLTEXT_PKG AS

procedure csn_AddHtmlText(

	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
)
as
begin

insert into {databaseOwner}csn_HtmlText (
	ModuleId,
	DesktopHtml,
	DesktopSummary,
	CreatedByUser,
	CreatedDate
) 
values (
	i_ModuleId,
	i_DesktopHtml,
	i_DesktopSummary,
	i_UserID,
	sysdate
);

end csn_AddHtmlText;

procedure csn_GetHtmlText (
	i_ModuleId in number,
    o_rc1      out {databaseOwner}global_pkg.rct1
)
as
begin

open o_rc1 for
select *
from {databaseOwner}csn_HtmlText
where  ModuleId = i_ModuleId;

end csn_GetHtmlText;

procedure csn_UpdateHtmlText (
	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
)
as
begin

update {databaseOwner}csn_HtmlText
set    DesktopHtml    = i_DesktopHtml,
       DesktopSummary = i_DesktopSummary,
       CreatedByUser  = i_UserID,
       CreatedDate    = sysdate
where  ModuleId = i_ModuleId;

end csn_UpdateHtmlText;

END CSN_HTMLTEXT_PKG;
/