/***************************************************************/
/*****              OracleDataProvider                     *****/
/*****                                                     *****/
/*****                                                     *****/
/***** Note: To manually execute this script you must      *****/
/*****       perform a search and replace operation        *****/
/*****       for {databaseOwner}                           *****/
/*****                                                     *****/
/***************************************************************/

/** Create Table **/

DECLARE 
  v_exists NUMBER(1,0);
BEGIN
  v_exists := 0;
  SELECT COUNT(*)
  INTO v_exists
  FROM user_tables
  WHERE LOWER(TABLE_NAME) = LOWER('CSN_HTMLTEXT');
  
  IF v_exists = 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'CREATE TABLE {databaseOwner}scp_HtmlText(
			ModuleID number(10,0) NOT NULL,
			DesktopHtml nclob NOT NULL,
			DesktopSummary nclob,
			CreatedByUser number(10,0),
			CreatedDate date) TABLESPACE CSWS_DBO_DATA01_128K';
      EXECUTE IMMEDIATE 'ALTER TABLE {databaseOwner}scp_HtmlText ADD (CONSTRAINT PK_CSN_HHTMLTEXT PRIMARY KEY (ModuleID) USING INDEX TABLESPACE CSWS_DBO_INDEX01_128K)';
      EXECUTE IMMEDIATE 'ALTER TABLE {databaseOwner}scp_HtmlText ADD (CONSTRAINT FK_CSN_HHTMLTEXT_CSN_MODULES FOREIGN KEY (ModuleID) REFERENCES {databaseOwner}scp_Modules (ModuleID) ON DELETE CASCADE)';
    END;
  END IF;
END;
/

CREATE OR REPLACE PACKAGE {databaseOwner}CSN_HTMLTEXT_PKG AUTHID CURRENT_USER AS
procedure scp_AddHtmlText(

	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
);
procedure scp_GetHtmlText (
	i_ModuleId in number,
        o_rc1      out {databaseOwner}global_pkg.rct1
);
procedure scp_UpdateHtmlText (
	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
);
end CSN_HTMLTEXT_PKG;
/

CREATE OR REPLACE PACKAGE BODY {databaseOwner}CSN_HTMLTEXT_PKG AS

procedure scp_AddHtmlText(

	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
)
as
begin

insert into {databaseOwner}scp_HtmlText (
	ModuleId,
	DesktopHtml,
	DesktopSummary,
	CreatedByUser,
	CreatedDate
) 
values (
	i_ModuleId,
	i_DesktopHtml,
	i_DesktopSummary,
	i_UserID,
	sysdate
);

end scp_AddHtmlText;

procedure scp_GetHtmlText (
	i_ModuleId in number,
    o_rc1      out {databaseOwner}global_pkg.rct1
)
as
begin

open o_rc1 for
select *
from {databaseOwner}scp_HtmlText
where  ModuleId = i_ModuleId;

end scp_GetHtmlText;

procedure scp_UpdateHtmlText (
	i_ModuleId       in number,
	i_DesktopHtml    in nclob,
	i_DesktopSummary in nclob,
	i_UserID         in number
)
as
begin

update {databaseOwner}scp_HtmlText
set    DesktopHtml    = i_DesktopHtml,
       DesktopSummary = i_DesktopSummary,
       CreatedByUser  = i_UserID,
       CreatedDate    = sysdate
where  ModuleId = i_ModuleId;

end scp_UpdateHtmlText;

END CSN_HTMLTEXT_PKG;
/